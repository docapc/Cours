﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Animals
{
    public class Tiger : Animal
    {
        public override string GetRoar()
        {
            return "Grr";
        }
    }
}
