﻿// See https://aka.ms/new-console-template for more information
using DemoHeritage.Animaux;
using MaDemo;
using MaDemo.Animaux; 

Console.WriteLine("Hello, World!");



Animal chat = new Chat("",1)
{
    Nom = "MonChat"
};
Animal chien = new Chien("",1)
{
    Nom = "MonChien"
};


chat.Dormir();
chien.Dormir();

chat.Manger();
chien.Manger();

List<Animal> listAnimaux = new List<Animal>();
listAnimaux.Add(chat);
listAnimaux.Add(chien);

foreach (Animal animal in listAnimaux)
{
    animal.Manger();
    if(animal is Chat monChat)
    {
        monChat.Jouer();
    }
}

Chien chien2 = new Chien("monChien", 10);
Chien beagle = new Beagle("monBeagle", 11);

chien2.Courir();
beagle.Courir();


Console.ReadLine(); 