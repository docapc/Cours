﻿// See https://aka.ms/new-console-template for more information
using DemoException;

Console.WriteLine("Hello, World!");


try
{
    int.Parse("toto");
}
catch (ArgumentNullException ane)
{
    Console.WriteLine($"il y a un problème de type argument null exception: {ane.Message}");
}
catch (FormatException fe)
{
    Console.WriteLine($"il y a un problème de type format exception: {fe.Message}");
}
catch (Exception e)
{
    Console.WriteLine($"il y a un problème : {e.Message}");
}

try
{
    var cal = new Calcul();
    cal.Calc(-1, 2); 
}
catch (ArgumentException ae)
{

}
catch(CalculException me)
{
    Console.WriteLine($"{me.Message}"); 
}
finally
{
    Console.WriteLine("Ici je suis toujours éxécuté");

}


Console.ReadLine();