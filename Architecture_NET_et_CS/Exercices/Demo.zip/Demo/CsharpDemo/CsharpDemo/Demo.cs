﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpDemo
{
    public class Demo : IEquatable<Demo>
    {
        private int _val;


        public int? MonChiffre { get; set; } = null;

        public Demo(int valeur)
        {
            _val = valeur;
        } 

        public int Calcul(int a, int b, int c)
        {
            int i; 
            return a + b * c; 
        }

        

        public override string? ToString()
        {
            return $"Voici les valeurs de mon objet : {_val}";
        }

        /*public override bool Equals(object? obj)
        {
            Demo demo2 = (Demo)obj;

            string i = "5";
            int testResult;
            int.TryParse(i, out testResult); 

            if (obj is Demo test)
            {
               //test._val;
                //Demo demo = obj as Demo;
            }
        }*/

        public bool Equals(Demo? other)
        {
            return true; 
        }
    }
}
