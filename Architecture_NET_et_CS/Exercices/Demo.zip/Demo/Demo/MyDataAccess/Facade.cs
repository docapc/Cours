﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo
{
    public class Facade
    {

        private readonly SubSystem _subSystem = new SubSystem();
        private readonly SubSystem _subSystem2 = new SubSystem();

        /*internal Facade(SubSystem subSystem, SubSystem subSystem2)
        {
            _subSystem = subSystem;
            _subSystem2 = subSystem2; 
        }*/

        public bool Save()
        {
            return _subSystem.Save();
        }
    }
}
