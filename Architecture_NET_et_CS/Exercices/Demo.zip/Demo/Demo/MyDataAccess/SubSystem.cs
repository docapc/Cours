﻿namespace Demo
{
    internal class SubSystem
    {
        public bool Save()
        {
            //mon implémentation
            return true; 
        }
    }
}