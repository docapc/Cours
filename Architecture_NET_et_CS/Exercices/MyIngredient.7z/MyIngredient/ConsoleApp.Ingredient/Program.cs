﻿// See https://aka.ms/new-console-template for more information
using MyIngredient.Models;

Console.WriteLine("Hello, World!");

var writer = new Writer();
writer.Write(); 

Console.ReadLine();
