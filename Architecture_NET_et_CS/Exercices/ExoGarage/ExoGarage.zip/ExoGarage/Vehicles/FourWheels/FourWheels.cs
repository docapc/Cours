﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExoGarage
{
    internal class FourWheels : Vehicle//<FourWheelsSubType>
    {
        private FourWheelsSubType SubType { get; }
        public FourWheels(FourWheelsSubType subtype = Rules.DEFAULT_4W_SUBTYPE, string brand = Rules.DEFAULT_BRAND, 
            string model = Rules.DEFAULT_MODEL, VehicleState state = Rules.DEFAULT_STATE, 
            float mileage = Rules.DEFAULT_MILEAGE)
            : base(brand, model, state, mileage) 
        {
            WheelsNumber = Rules.DEFAULT_4W_NWHEELS;
            SubType = subtype; 
        }
//        VehicleState state = (VehicleState)input;
        public override string ToString()
        {
            return $"{SubType.GetString()} : {base.ToString()}";
        }

    }

 
}
