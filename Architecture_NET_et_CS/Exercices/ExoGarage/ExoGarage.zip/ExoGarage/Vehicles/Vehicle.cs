﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Type principale Contenue dans le Garage
/// Important : le nombre de roues n'est absoluement pas nécessaire et est juste la pour affichage
/// </summary>
namespace ExoGarage
{
    internal abstract class Vehicle // <T> where T : Enum //Ne fonctionne pas avec les génériques
    {       
        private static int _sid = 0;
        
        protected readonly int _id;
        //protected readonly string _subtype; // force à intialiser dans le constructeur du parent (bloque l'initialisation dans le constructeur de l'enfant)
        protected readonly string _brand;
        protected readonly string _model;
        protected float _mileage; // On suppose que le véhicule pourra changer cette valeur

        // protected abstract string SubType { get; } // propriété en readonly mais même problème que l'attribut en read only
//        protected Enum SubType{ get; init; } // init permet de faire une propriété héritée readonly quand même initialisable dans le constructeur de l'enfant       
//        protected T SubType { get; init; } // très compliqué d'hériter d'un générique abstract...       
        public int WheelsNumber { get; protected set; } // On suppose qu'un véhicule peut perdre une roue si il le veut...
        public VehicleState State { get; set; } // On doit pouvoir accéder à/et changer l'état.                                                

        public Vehicle(string brand, string model, VehicleState state, float mileage)
        {
            // Aucun types nullable la dedans
            _id = ++_sid; // le id sert au stats du garage, pas à l'indexation dans la list
            _brand = brand;
            _model = model;
            _mileage = mileage;
            State = state;
            //_subtype = subtype; // forcément définie ici et pas dans les enfant à cause du readonly
            //SubType = subtype; // même chose que pour l'attribut
        }

        /// <summary>
        /// Permet d'afficher un véhicule via Console.Write()
        /// </summary>
        /// <returns>string</returns>
        public override string ToString() 
        {
            return $"({WheelsNumber} roues), Marque : {_brand}, Modèle : {_model}, Etat : {State.GetString()}, ({_mileage} {Rules.MILEAGE_UNIT}), Id du véhicule = {_id}";
        }
    }
}
