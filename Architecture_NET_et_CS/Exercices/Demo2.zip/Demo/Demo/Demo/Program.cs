﻿// See https://aka.ms/new-console-template for more information
using Demo;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        Facade facade = new Facade();
        facade.Save();

        Console.ReadLine();
    }
}
