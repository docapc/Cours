﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaDemo.Animaux
{
    public class Chat : Animal
    {
        public Chat(string nom, int age) : base(nom, age)
        {
        }

        public override void Manger()
        {
            Console.WriteLine("Le chat mange");
        }

        public void Jouer()
        {
            Console.WriteLine("Je joue");
        }
    }
}
