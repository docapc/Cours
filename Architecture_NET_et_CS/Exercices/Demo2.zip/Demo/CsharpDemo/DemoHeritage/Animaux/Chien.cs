﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaDemo.Animaux
{
    public class Chien : Animal
    {
        public Chien(string nom, int age) : base(nom, age)
        {
        }

        public override void Manger()
        {
            Console.WriteLine("Le chien mange");
        }

        public virtual void Courir()
        {
            Console.WriteLine("Je suis un chien et je cours");
        }
    }
}
