﻿using MaDemo.Animaux;

namespace DemoHeritage.Animaux
{
    public class Beagle : Chien
    {
        public Beagle(string nom, int age) : base(nom, age)
        {
        }

        public override void Courir()
        {
            Console.WriteLine("Je suis un beagle et je cours");
        }
    }
}
