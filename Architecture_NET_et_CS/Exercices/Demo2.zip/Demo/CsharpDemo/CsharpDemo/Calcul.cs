﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpDemo
{
    public class Calcul
    {

        


        public Retour CalculInt(int a, int b, out int c, ref int d, ref Calcul calc)
        {
            a++;
            c = a + b +d;
            d = c; 

            return new Retour
            {
                Val1 =a, 
                Val3 =b, 
            }; 
        }

        public int Calc2 (int a, int b = 5, int c =10)
        {
            return a + b + c;  
        }
    }
}
