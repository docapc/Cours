﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpDemo
{
    public class Demo2
    {

        private int _a; 
        private int _b;
        private int _c; 


        public int GetA()
        {
            return _a;
        }

        private void SetterA(int nouvelleVal)
        {
            _a = nouvelleVal;
        }

        public int MaProp {
            get => _a; 
            set => _a = value;  
        }

        private int age;

        public int Age
        {
            get { return age; }
            set { 
                if(age > 0)
                    age = value; 
            }
        }

        public static int MyProperty { get; set; } = 50;  



        public int CalcProp { get => MaProp / 2; }


        public Demo2()
        {
            var test = MaProp; 
        }

        public Demo2(int a, int b)
        {
            _a = a; 
            _b = b;  
        }

        public Demo2(int a, int b, int c) : this(a,b)
        {
            _c = c; 
        }


        public void DisplayProperty()
        {
            Console.WriteLine(MyProperty); 
        }
    }
}
