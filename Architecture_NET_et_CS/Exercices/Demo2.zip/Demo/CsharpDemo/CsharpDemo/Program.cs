﻿// See https://aka.ms/new-console-template for more information
using CsharpDemo;
using System.Text;

Console.WriteLine("Hello, World!");


int monChiffre = 0;
int monChriffre2 = monChiffre; 

string monString = "";

bool test = true;

bool test3 = !false ; 

Boolean t = false; 

Demo demo = new Demo(10);
Demo demo2 = demo;


Demo demo3=new Demo(11); 



if(demo == demo2) {
   Console.WriteLine("c'est equal");
}

if (demo.Equals(demo3))
{
    Console.WriteLine("c'est equal");
}
else
{
    Console.WriteLine("c'est !=");
}

if( monChiffre == monChriffre2)
{

}
//Console.WriteLine(test3);


int retour = demo.Calcul(1, 2, 5);
Console.WriteLine(retour);
 


for (int i =0; i<100; i++)
{
    Console.WriteLine(i);
}

for (int i = 0; i < 100; i++)
{
    Console.WriteLine(i);
}

int[] array = {1,2,3};

int[,] array2 = new int[,] { { 1, 2, 3 }, { 1, 2, 3 } };

Console.WriteLine(array[2]); 

int j = 0;
for ( j = 0; j < 3; j++)
{
    Console.WriteLine(array[j]);
}


int j2=0; 
while (j2 < 100)
{
    Console.WriteLine(j2);
    j2++; 
}




string cc = "Coucou";

string cc2 = "Coucou";

string c3 = string.Empty;

string c4 = cc + "test";
c4 = c4 + "test2";

StringBuilder sb = new StringBuilder();

sb.Append(cc);
sb.Append(cc2);
sb.Append(c4);

if(cc == cc2)
{
    Console.WriteLine("Equal"); 
}

Console.WriteLine($"j'affiche {cc +cc2}, coucou3");


Demo2 maDemo = new Demo2();
Demo2 maDemo2 = new Demo2();
maDemo.Age = 10; 

var monAge = maDemo.Age;

Console.WriteLine(Demo2.MyProperty);

Demo2.MyProperty = 25;
Console.WriteLine(Demo2.MyProperty);


Demo maDemo4 = new Demo(10);

Console.WriteLine($"Voici les valeurs de mon objet : {maDemo4.MonChiffre}");



var calcul = new Calcul();
int v1 = 1;
int v2 = 2;
int v3;
int v4=5;
Calcul c1 = null;
var resultReturn = calcul.CalculInt(v1, v2, out v3, ref v4, ref c1);

//resultReturn.Item1 = 5;  

Console.WriteLine($"Result  : {v1}");
Console.WriteLine($"Result  : {v3}");
Console.WriteLine($"Result  : {v4}");
Console.WriteLine($"Result  : {resultReturn}");


calcul.Calc2(5,c:8);

var chatEnum = MonEnum.Chat;

var chatConst = DemoConst.CHAT;


var personne = new Personne();
personne.Animal = MonEnum.Cochon; 


Console.ReadLine();



