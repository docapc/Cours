﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpDemo
{
    public static class DemoConst
    {
        public const string CHAT = "CHAT"; 
        public const string CHIEN = "CHIEN"; 
        public const string COCHON = "COCHON";



        public static readonly Calcul cal;

        static DemoConst()
        {
            cal = new Calcul();
        }
    }
}
