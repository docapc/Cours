﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoException
{
    public static class IntegerExtension
    {

        public static void MonJolieObjet(this object a)
        {
            Console.WriteLine($"je suis beau {a}");
        }
    }
}
