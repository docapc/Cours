﻿using System.Runtime.Serialization;

namespace DemoException
{
    public class CalculException : Exception
    {
        public int A { get; set; }

        public int B { get; set; }

        public CalculException(string message, int a, int b) : base(message)
        {
            A= a;
            B= b;
        }

        public CalculException(string message, int a , int b, Exception innerException) : base(message, innerException)
        {
            A = a;
            B = b;
        }

        public override string Message => $"{base.Message}, Arg 1 :{A}, Arg 2: {B}";
    }
}
