﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoException
{
    internal interface ITest3
    {
        public int MyProperty { get; set; }

        public int MyProperty2 { get; set; }
    }
}
