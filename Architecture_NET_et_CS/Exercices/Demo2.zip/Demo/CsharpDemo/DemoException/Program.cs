﻿// See https://aka.ms/new-console-template for more information
using DemoException;

Console.WriteLine("Hello, World!");


try
{
    int.Parse("toto");
}
catch (ArgumentNullException ane)
{
    Console.WriteLine($"il y a un problème de type argument null exception: {ane.Message}");
}
catch (FormatException fe)
{
    Console.WriteLine($"il y a un problème de type format exception: {fe.Message}");
}
catch (Exception e)
{
    Console.WriteLine($"il y a un problème : {e.Message}");
}

try
{
    var cal = new Calcul();
    cal.Calc(-1, 2); 
}
catch (ArgumentException ae)
{

}
catch(CalculException me)
{
    Console.WriteLine($"{me.Message}"); 
}
catch(Exception e)
{
    Console.WriteLine($"grosse erreur : je ne sais pas quoi faire");
}
finally
{
    Console.WriteLine("Ici je suis toujours éxécuté");

}




int i = new Random().Next(6);

Console.WriteLine($"ma val : {i}");
switch (i)
{
    case 0:
    case 1:
    case 2:
    case 3:
    case 4:
        Console.WriteLine("C'est perdu");
        break;
    case 5:
        Console.WriteLine("C'est gagné"); 
        break;
    case 6:
        Console.WriteLine("dommage !");
        break;

    default:
        Console.WriteLine("Dommage .... ");
        break; 
}

CalculationExtension.MaNouvelleMéthodeDeCalcul(new Calcul(),1,2); 

//calccul.MaNouvelleMéthodeDeCalcul(1,2);

var cal2 = new Calcul();
cal2.MaNouvelleMéthodeDeCalcul(2, 3);

List<ITest3> test = new List<ITest3>();

test.FirstOrDefault();

int test5 = 5;
test5.MonJolieObjet();


cal2.MonJolieObjet();
i.MonJolieObjet();  


Console.ReadLine();