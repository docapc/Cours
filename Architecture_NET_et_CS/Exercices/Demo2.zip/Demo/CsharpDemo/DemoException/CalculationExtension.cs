﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoException
{
    public static class CalculationExtension
    {

        public static void MaNouvelleMéthodeDeCalcul(this Calcul calcul, int a, int b)
        {

        }
    }
}
