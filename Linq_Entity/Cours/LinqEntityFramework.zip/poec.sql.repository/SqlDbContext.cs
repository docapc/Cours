﻿using Microsoft.EntityFrameworkCore;

namespace poec.sql.repository;

public class SqlDbContext : DbContext
{
    private string ConnectionString { get; }

    protected SqlDbContext(string connectionString)
    {
        ConnectionString = connectionString;
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);

        optionsBuilder.UseSqlServer(ConnectionString);
    }

    public override DbSet<TEntity> Set<TEntity>()
    {
        ChangeTracker.LazyLoadingEnabled = false;
        ChangeTracker.AutoDetectChangesEnabled = false;
        ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;

        return base.Set<TEntity>();
    }
}