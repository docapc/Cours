using Xunit;

namespace poec.sql.repository.tests
{
    public class SqlRepositoryTest
    {
        [Fact]
        public void GetTest()
        {

        }
    }
}