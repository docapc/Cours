﻿namespace MyCompany.MyGarage.Models
{
    public enum VehicleType
    {
        TwoWheel,
        FourWheel
    }
}
